﻿namespace ConsoleApp1
{
    internal class Program
    {
        static int y = 0;
        static int d = 4;
        /* static void Main(string[] args)
        {
            int number = 24;
            string name = "David";
            int[,] test = new int[4, 7];
            string[] DaysOfTheWeek = new string[7];
            DaysOfTheWeek[0] = "Monday";
            DaysOfTheWeek[1] = "Tuesday";
            DaysOfTheWeek[2] = "Wednesday";
            DaysOfTheWeek[3] = "Thursday";
            DaysOfTheWeek[4] = "Friday";
            DaysOfTheWeek[5] = "Sataurday";
            DaysOfTheWeek[6] = "Sunday";

            foreach (var day in DaysOfTheWeek)
            {
                Console.WriteLine("The day is " + day);
            }


            Console.WriteLine($"My name is {name} and my age is {number}");
            Console.WriteLine(name.Length);
            Console.WriteLine(name.IndexOf("d"));
            Console.WriteLine("Beep");
            Console.WriteLine(DaysOfTheWeek[5]);

            DateTime date = DateTime.Today;
            Console.WriteLine(date);

            DateTime starWarsFilm = new DateTime(1977, 5, 25);
            var diff = date.Subtract(starWarsFilm);
            Console.WriteLine(diff.TotalDays);

            Console.WriteLine("What is your pets name?");
            string petsName = Console.ReadLine();
            Console.WriteLine($"Your pets name is {petsName}");
            Random rand = new Random();
            int num = rand.Next(1, 100);
            int secondnum = rand.Next(-10, 10);
            Console.WriteLine(num);
            Console.WriteLine(secondnum);
            Console.WriteLine(Math.Sqrt(num * secondnum));

            //int division = num % secondnum;
            //switch (division)
            //{
            //    case 0:
            //        Console.WriteLine("Value was 0");
            //        break;
            //        case 1:
            //        Console.WriteLine("Value was 1");
            //        break;
            //    case 2:
            //        Console.WriteLine("Value was 2");
            //        break;
            //}
            //Console.WriteLine(division);
            //if (num >= 5)
            //{
            //    Console.WriteLine(num + " It's a high number");
            //}
            //else
            //{
            //    Console.WriteLine(num + " It's a low number");
            //}
            Console.WriteLine("date formatted is " + getDate());
            try
            {
                
                Console.WriteLine(num / y);
            }
            catch (Exception e)
            {
                Console.WriteLine("Encountered an error to " + e.ToString());
                
            }
            finally
            {
                y = 3;
                Console.WriteLine(num / y);
            }
        }

        static string getDate()
        {
            DateTime currentDate = DateTime.Today;
            string date = currentDate.ToString();
            string yearTime = date.Remove(0, 6);
            string year = yearTime.Remove(4);
            string daymonth = date.Remove(5);
            string month = daymonth.Remove(0, 3);
            string day = date.Remove(2);

            Console.WriteLine(currentDate);
            Console.WriteLine(year);
            Console.WriteLine(month);
            Console.WriteLine(day);
            Console.WriteLine(year + month + day);
            return year + month + day;
        }

        private static void SomeMethod(int v1, int v2)
        {
            throw new NotImplementedException();
        }

        static void SomeMethod()
        {
            
        }

        static int tester(int number)
        {
            for (int i = 0; i < 10; i++)
            {
                number = number * number;
            }
                return number;
        }
        */
    }
}