﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    internal class RollDice
    {
        static void Main(string[] args)
        {
            bool tryAgain = true;
            while (tryAgain == true)
            {

                // Generating random numbers and showing results

                Random randomNumber = new Random();

                int humanDie1 = randomNumber.Next(1, 7);
                int humanDie2 = randomNumber.Next(1, 7);

                Console.WriteLine("Your numbers are: ");
                Console.WriteLine(humanDie1);
                Console.WriteLine("+");
                Console.WriteLine(humanDie2);
                Console.WriteLine("Total: " + (humanDie1 + humanDie2));

                Console.WriteLine(" Press any button to continue... ");
                Console.ReadLine();

                int computerDie1 = randomNumber.Next(1, 7);
                int computerDie2 = randomNumber.Next(1, 7);

                Console.WriteLine("The computer's numbers are: ");
                Console.WriteLine(computerDie1);
                Console.WriteLine("+");
                Console.WriteLine(computerDie2);
                Console.WriteLine("Total: " + (computerDie1 + computerDie2));

                // Checking if Player has won

                if (humanDie1 + humanDie2 > computerDie1 + computerDie2)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Congratulations! You win! ");
 
                } else if (humanDie1 + humanDie2 < computerDie1 + computerDie2)
                {
                    Console.WriteLine("Oh no, you lost... ");
                    Console.WriteLine("Try again? ");
                } else
                {
                    Console.WriteLine("It's a stalemate! ");                 
                }
                Console.WriteLine("Do you want to try again? ");
                Console.WriteLine("y/n");
                string check = Console.ReadLine();
                if (check == "y")
                {
                    tryAgain = true;
                }
                else
                {
                    Console.WriteLine("Thanks for playing. ");
                    tryAgain = false;
                }
            }
        }
    }
}
